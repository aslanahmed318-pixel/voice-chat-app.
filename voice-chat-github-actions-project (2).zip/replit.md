# Voice Chat

A mobile voice chat prototype for discovering rooms, joining live conversations, and starting lightweight games together.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/voice-chat/app/(tabs)/index.tsx` — dashboard and room discovery
- `artifacts/voice-chat/app/(tabs)/room.tsx` — live room with 12 speaker slots and mic controls
- `artifacts/voice-chat/app/(tabs)/games.tsx` — room games hub
- `artifacts/voice-chat/constants/colors.ts` — midnight, mint, coral product palette
- `artifacts/voice-chat/assets/images/voice-chat-icon.png` — generated app icon

## Architecture decisions

- The first build is frontend-only and uses local component state for demo interactions; no backend or database is required for the UI prototype.
- Expo Router tabs are used for the three main product surfaces so the dashboard, active room, and games hub are always one tap apart.
- The room deliberately keeps all 12 mic slots visible so speaker presence is legible without a second screen.
- The visual system uses mint for primary listening/speaking energy and coral for live or attention states against a dark room canvas.

## Product

- Browse and rejoin rooms from a dashboard.
- Enter a live room with 12 visible mic slots, active speaker state, mute/unmute control, invite, and share actions.
- Start a room game from the games hub with local invited-state feedback.

## User preferences

- The requested implementation direction is Flutter/mobile-first voice chat UI.

## Gotchas

- The preview workflow uses the managed Expo service and injected runtime variables; do not start Expo directly from the shell.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
