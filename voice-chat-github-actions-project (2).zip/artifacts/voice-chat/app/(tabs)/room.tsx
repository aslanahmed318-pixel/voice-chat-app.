import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type Speaker = { name: string; initials: string; color: 'mint' | 'coral' | 'gold' | 'sky'; role?: string; muted?: boolean };

const speakers: Speaker[] = [
  { name: 'مينا', initials: 'من', color: 'coral', role: 'المضيف' },
  { name: 'كاي', initials: 'كي', color: 'sky', role: 'مضيف مشارك' },
  { name: 'آشا', initials: 'آش', color: 'mint', role: 'أنت' },
  { name: 'نوح', initials: 'نو', color: 'gold' },
  { name: 'لينا', initials: 'لن', color: 'sky' },
  { name: 'سام', initials: 'سم', color: 'coral', muted: true },
  { name: 'جولز', initials: 'جل', color: 'gold' },
  { name: 'إيناس', initials: 'إي', color: 'mint' },
  { name: 'عمر', initials: 'عم', color: 'coral' },
  { name: 'راي', initials: 'را', color: 'sky', muted: true },
  { name: 'ثيو', initials: 'ثي', color: 'gold' },
  { name: 'مايا', initials: 'ما', color: 'mint' },
];

export default function RoomScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [muted, setMuted] = useState(false);
  const [speaking, setSpeaking] = useState('آشا');
  const [isInvited, setIsInvited] = useState(false);
  const topInset = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const toggleMic = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setMuted((current) => !current);
    setSpeaking((current) => (current === 'آشا' ? '' : 'آشا'));
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background, direction: 'rtl' }]}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: topInset + 8, paddingBottom: insets.bottom + 126 }}>
        <View style={styles.roomHeader}>
          <Pressable testID="room-back" style={[styles.headerIcon, { backgroundColor: colors.surfaceRaised }]} onPress={() => router.push('/')}>
            <Feather name="chevron-right" size={21} color={colors.foreground} />
          </Pressable>
          <View style={styles.roomHeaderCenter}>
            <View style={styles.roomLiveLine}>
              <View style={[styles.liveDot, { backgroundColor: colors.coral }]} />
              <Text style={[styles.roomLiveText, { color: colors.coral }]}>غرفة مباشرة</Text>
            </View>
            <Text style={[styles.roomHeaderTitle, { color: colors.foreground }]}>الصالة الليلية</Text>
          </View>
          <Pressable testID="room-more" style={[styles.headerIcon, { backgroundColor: colors.surfaceRaised }]} onPress={() => undefined}>
            <Feather name="more-horizontal" size={20} color={colors.foreground} />
          </Pressable>
        </View>

        <View style={styles.roomIntro}>
          <Text style={[styles.roomTitle, { color: colors.foreground }]}>مساحة هادئة لك.</Text>
          <Text style={[styles.roomDescription, { color: colors.mutedForeground }]}>اجلس معنا، شارك فكرة، أو استمع قليلًا.</Text>
          <View style={styles.roomStats}>
            <View style={styles.statItem}>
              <Feather name="users" size={14} color={colors.mint} />
              <Text style={[styles.statText, { color: colors.mutedForeground }]}>١٢ في الغرفة</Text>
            </View>
            <View style={styles.statItem}>
              <Feather name="clock" size={14} color={colors.mint} />
              <Text style={[styles.statText, { color: colors.mutedForeground }]}>منذ ٤٨ دقيقة</Text>
            </View>
          </View>
        </View>

        <View style={[styles.waveCard, { backgroundColor: colors.surfaceSoft, borderColor: colors.border }]}>
          <View style={styles.waveHeader}>
            <View style={styles.nowSpeaking}>
              <View style={[styles.tinyPulse, { backgroundColor: colors.mint }]} />
              <Text style={[styles.nowSpeakingLabel, { color: colors.mint }]}>{speaking ? `${speaking} يتحدث الآن` : 'الغرفة هادئة'}</Text>
            </View>
            <Text style={[styles.waveTime, { color: colors.mutedForeground }]}>٠٠:٤٨:١٢</Text>
          </View>
          <View style={styles.waveform}>
            {[16, 30, 22, 42, 27, 50, 35, 24, 44, 19, 34, 52, 29, 21, 38, 26, 45, 31, 17, 28, 39, 25, 48, 22, 34, 18, 43, 27].map((height, index) => (
              <View key={index} style={[styles.waveBar, { height, backgroundColor: index % 4 === 0 ? colors.coral : colors.mint, opacity: index < 15 ? 0.95 : 0.48 }]} />
            ))}
          </View>
        </View>

        <View style={styles.sectionRow}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>على المنصة</Text>
          <Text style={[styles.sectionCount, { color: colors.mutedForeground }]}>١٢ ميكروفونًا</Text>
        </View>

        <View style={styles.speakerGrid}>
          {speakers.map((speaker) => (
            <SpeakerTile key={speaker.name} speaker={speaker} active={speaking === speaker.name} colors={colors} onPress={() => setSpeaking((current) => (current === speaker.name ? '' : speaker.name))} />
          ))}
        </View>

        <View style={[styles.roomNote, { backgroundColor: colors.surfaceRaised }]}>
          <View style={[styles.noteIcon, { backgroundColor: colors.gold }]}>
            <Feather name="message-circle" size={16} color={colors.ink} />
          </View>
          <Text style={[styles.noteText, { color: colors.mutedForeground }]}>كن لطيفًا، اترك مساحة للآخرين، ومرّر الميكروفون عندما تكون مستعدًا.</Text>
        </View>
      </ScrollView>

      <View style={[styles.controlBar, { backgroundColor: colors.card, borderColor: colors.border, paddingBottom: Math.max(insets.bottom, 14) }]}>
        <Pressable testID="room-invite" onPress={() => setIsInvited((current) => !current)} style={[styles.smallControl, { backgroundColor: colors.surfaceRaised }]}>
          <Feather name={isInvited ? 'check' : 'user-plus'} size={19} color={colors.foreground} />
          <Text style={[styles.smallControlText, { color: colors.foreground }]}>{isInvited ? 'تم الإرسال' : 'دعوة'}</Text>
        </Pressable>
        <Pressable testID="mic-toggle" onPress={toggleMic} style={({ pressed }) => [styles.micButton, { backgroundColor: muted ? colors.coral : colors.mint, transform: [{ scale: pressed ? 0.96 : 1 }] }]}>
          <Feather name={muted ? 'mic-off' : 'mic'} size={23} color={muted ? colors.destructiveForeground : colors.ink} />
        </Pressable>
        <Pressable testID="room-share" onPress={() => undefined} style={[styles.smallControl, { backgroundColor: colors.surfaceRaised }]}>
          <Feather name="share-2" size={19} color={colors.foreground} />
          <Text style={[styles.smallControlText, { color: colors.foreground }]}>مشاركة</Text>
        </Pressable>
      </View>
    </View>
  );
}

function SpeakerTile({ speaker, active, colors, onPress }: { speaker: Speaker; active: boolean; colors: ReturnType<typeof useColors>; onPress: () => void }) {
  const avatarColor = colors[speaker.color];
  return (
    <Pressable testID={`speaker-${speaker.name}`} onPress={onPress} style={({ pressed }) => [styles.speakerTile, { backgroundColor: active ? colors.surfaceRaised : colors.card, borderColor: active ? colors.mint : colors.border, opacity: pressed ? 0.78 : 1 }]}>
      <View style={[styles.speakerAvatar, { backgroundColor: avatarColor }]}>
        <Text style={[styles.speakerInitials, { color: colors.ink }]}>{speaker.initials}</Text>
        {active && <View style={[styles.speakingRing, { borderColor: colors.mint }]} />}
      </View>
      <Text style={[styles.speakerName, { color: colors.foreground }]}>{speaker.name}</Text>
      <View style={styles.speakerMeta}>
        {speaker.role ? <Text style={[styles.speakerRole, { color: speaker.role === 'المضيف' ? colors.coral : colors.mutedForeground }]}>{speaker.role}</Text> : null}
        {speaker.muted ? <Feather name="mic-off" size={11} color={colors.mutedForeground} /> : active ? <View style={[styles.activeDot, { backgroundColor: colors.mint }]} /> : null}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  roomHeader: { paddingHorizontal: 20, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  headerIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  roomHeaderCenter: { alignItems: 'center' },
  roomLiveLine: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, marginBottom: 5 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  roomLiveText: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.1 },
  roomHeaderTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  roomIntro: { paddingHorizontal: 24, paddingTop: 28, paddingBottom: 21, alignItems: 'flex-end' },
  roomTitle: { fontFamily: 'Inter_700Bold', fontSize: 30, letterSpacing: -1, marginBottom: 8, textAlign: 'right' },
  roomDescription: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, maxWidth: 310, textAlign: 'right' },
  roomStats: { flexDirection: 'row-reverse', gap: 18, marginTop: 16 },
  statItem: { flexDirection: 'row-reverse', gap: 6, alignItems: 'center' },
  statText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  waveCard: { marginHorizontal: 20, padding: 17, borderRadius: 20, borderWidth: 1, marginBottom: 27 },
  waveHeader: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center' },
  nowSpeaking: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7 },
  tinyPulse: { width: 7, height: 7, borderRadius: 4 },
  nowSpeakingLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  waveTime: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  waveform: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', height: 54, marginTop: 14 },
  waveBar: { width: 4, borderRadius: 3 },
  sectionRow: { paddingHorizontal: 20, flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 13 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, letterSpacing: -0.4 },
  sectionCount: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  speakerGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', paddingHorizontal: 20, gap: 9 },
  speakerTile: { width: '23.5%', minHeight: 105, borderRadius: 16, borderWidth: 1, alignItems: 'center', paddingTop: 12, paddingBottom: 8 },
  speakerAvatar: { width: 43, height: 43, borderRadius: 22, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  speakerInitials: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  speakingRing: { position: 'absolute', width: 51, height: 51, borderRadius: 26, borderWidth: 2 },
  speakerName: { fontFamily: 'Inter_600SemiBold', fontSize: 11, marginTop: 8 },
  speakerMeta: { height: 15, alignItems: 'center', justifyContent: 'center', flexDirection: 'row-reverse', gap: 4 },
  speakerRole: { fontFamily: 'Inter_500Medium', fontSize: 9 },
  activeDot: { width: 5, height: 5, borderRadius: 3 },
  roomNote: { marginHorizontal: 20, marginTop: 24, padding: 14, borderRadius: 15, flexDirection: 'row-reverse', alignItems: 'center', gap: 11 },
  noteIcon: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  noteText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, textAlign: 'right' },
  controlBar: { position: 'absolute', left: 14, right: 14, bottom: 8, borderRadius: 23, minHeight: 76, borderWidth: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-around', paddingTop: 10, shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 18, shadowOffset: { width: 0, height: 7 }, elevation: 8 },
  smallControl: { width: 82, height: 51, borderRadius: 16, alignItems: 'center', justifyContent: 'center', gap: 4 },
  smallControlText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  micButton: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center' },
});