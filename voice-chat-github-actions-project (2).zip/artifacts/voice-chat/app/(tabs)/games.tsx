import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useState } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type Game = { title: string; description: string; players: string; icon: keyof typeof Feather.glyphMap; color: 'coral' | 'gold' | 'sky' };

const games: Game[] = [
  { title: 'الرسم السريع', description: 'سمّها قبل انتهاء الوقت.', players: 'من ٢ إلى ١٢ لاعبًا', icon: 'zap', color: 'coral' },
  { title: 'سباق الكلمات', description: 'ابنوا قصة، كلمة تلو الأخرى.', players: 'من ٣ إلى ٢٠ لاعبًا', icon: 'message-circle', color: 'gold' },
  { title: 'اختبار الصوت', description: 'خمن الصوت وثق بحدسك.', players: 'من ٢ إلى ٨ لاعبين', icon: 'volume-2', color: 'sky' },
];

export default function GamesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const topInset = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const startGame = async (title: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setActiveGame((current) => (current === title ? null : title));
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background, direction: 'rtl' }]}>
      <StatusBar style="light" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: topInset + 8, paddingBottom: insets.bottom + 112 }}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.coral }]}>اللعب / ٠٣</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>العبوا معًا.</Text>
          </View>
          <View style={[styles.headerIcon, { backgroundColor: colors.surfaceRaised }]}>
            <Feather name="sliders" size={18} color={colors.foreground} />
          </View>
        </View>

        <View style={[styles.introCard, { backgroundColor: colors.surfaceRaised }]}>
          <View style={[styles.introIcon, { backgroundColor: colors.mint }]}>
            <Feather name="grid" size={22} color={colors.ink} />
          </View>
          <Text style={[styles.introTitle, { color: colors.foreground }]}>شرارة صغيرة للغرفة.</Text>
          <Text style={[styles.introBody, { color: colors.mutedForeground }]}>ابدأ لعبة سريعة من دون مغادرة المحادثة. سيصل الجميع في الغرفة إلى دعوة.</Text>
          <View style={styles.playerPills}>
            <PlayerPill initials="MN" color={colors.coral} colors={colors} />
            <PlayerPill initials="KH" color={colors.sky} colors={colors} />
            <PlayerPill initials="AS" color={colors.mint} colors={colors} />
            <View style={[styles.morePill, { backgroundColor: colors.card }]}>
              <Text style={[styles.morePillText, { color: colors.mutedForeground }]}>+9</Text>
            </View>
            <Text style={[styles.joinedText, { color: colors.mutedForeground }]}>في الصالة الليلية</Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>اختر لعبة</Text>
          <Text style={[styles.sectionHint, { color: colors.mutedForeground }]}>بدون تحميل</Text>
        </View>

        <View style={styles.gameList}>
          {games.map((game, index) => (
            <GameCard
              key={game.title}
              game={game}
              index={index}
              active={activeGame === game.title}
              colors={colors}
              onPress={() => startGame(game.title)}
            />
          ))}
        </View>

        <View style={[styles.tipCard, { borderColor: colors.border }]}>
          <Feather name="info" size={16} color={colors.mint} />
          <Text style={[styles.tipText, { color: colors.mutedForeground }]}>تعمل الألعاب بشكل أفضل مع ٣ إلى ٨ أشخاص. أبقِ الميكروفون مفتوحًا ودع الفوضى تبدأ.</Text>
        </View>
      </ScrollView>
    </View>
  );
}

function PlayerPill({ initials, color, colors }: { initials: string; color: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[styles.playerPill, { backgroundColor: color, borderColor: colors.surfaceRaised }]}>
      <Text style={[styles.playerPillText, { color: colors.ink }]}>{initials}</Text>
    </View>
  );
}

function GameCard({
  game,
  index,
  active,
  colors,
  onPress,
}: {
  game: Game;
  index: number;
  active: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  const fill = colors[game.color];
  return (
    <Pressable testID={`game-${index}`} onPress={onPress} style={({ pressed }) => [styles.gameCard, { backgroundColor: colors.card, borderColor: active ? fill : colors.border, opacity: pressed ? 0.84 : 1 }]}>
      <View style={[styles.gameIcon, { backgroundColor: fill }]}>
        <Feather name={game.icon} size={21} color={colors.ink} />
      </View>
      <View style={styles.gameCopy}>
        <Text style={[styles.gameTitle, { color: colors.foreground }]}>{game.title}</Text>
        <Text style={[styles.gameDescription, { color: colors.mutedForeground }]}>{game.description}</Text>
        <Text style={[styles.gamePlayers, { color: colors.mutedForeground }]}>{game.players}</Text>
      </View>
      <View style={[styles.playButton, { backgroundColor: active ? fill : colors.surfaceRaised }]}>
        <Feather name={active ? 'check' : 'play'} size={16} color={active ? colors.ink : colors.foreground} />
      </View>
      {active && <Text style={[styles.activeLabel, { color: fill }]}>تمت الدعوة</Text>}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 25 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1.7, marginBottom: 8 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, letterSpacing: -1, textAlign: 'right' },
  headerIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  introCard: { marginHorizontal: 20, borderRadius: 23, padding: 20, marginBottom: 29 },
  introIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  introTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, letterSpacing: -0.5, marginBottom: 8, textAlign: 'right' },
  introBody: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, maxWidth: 295, textAlign: 'right' },
  playerPills: { flexDirection: 'row-reverse', alignItems: 'center', marginTop: 19 },
  playerPill: { width: 27, height: 27, borderRadius: 14, borderWidth: 2, marginRight: -6, justifyContent: 'center', alignItems: 'center' },
  playerPillText: { fontFamily: 'Inter_700Bold', fontSize: 8 },
  morePill: { width: 27, height: 27, borderRadius: 14, borderWidth: 2, borderColor: '#1c2b29', marginRight: 8, alignItems: 'center', justifyContent: 'center' },
  morePillText: { fontFamily: 'Inter_700Bold', fontSize: 8 },
  joinedText: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  sectionHeader: { paddingHorizontal: 20, flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, letterSpacing: -0.4 },
  sectionHint: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  gameList: { paddingHorizontal: 20, gap: 11 },
  gameCard: { minHeight: 102, borderWidth: 1, borderRadius: 19, padding: 14, flexDirection: 'row-reverse', alignItems: 'center', position: 'relative' },
  gameIcon: { width: 48, height: 48, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  gameCopy: { flex: 1, marginRight: 13, paddingLeft: 5 },
  gameTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 15, marginBottom: 4, textAlign: 'right' },
  gameDescription: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, textAlign: 'right' },
  gamePlayers: { fontFamily: 'Inter_500Medium', fontSize: 10, marginTop: 6, textAlign: 'right' },
  playButton: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  activeLabel: { position: 'absolute', top: 10, right: 14, fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 0.8 },
  tipCard: { marginHorizontal: 20, marginTop: 25, padding: 14, borderRadius: 16, borderWidth: 1, flexDirection: 'row-reverse', gap: 10, alignItems: 'flex-start' },
  tipText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, textAlign: 'right' },
});