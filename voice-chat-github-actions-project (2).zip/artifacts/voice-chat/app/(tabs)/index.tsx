import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useMemo } from 'react';
import {
  Pressable,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

const rooms = [
  { title: 'الصالة الليلية', subtitle: 'حكايات، موسيقى، بلا ضغط', people: '٨ يتحدثون', color: 'mint', initials: 'LN' },
  { title: 'مصمّمون بعد الغروب', subtitle: 'اعرض وشارك', people: '٢٤ يستمعون', color: 'coral', initials: 'DA' },
  { title: 'استراحة الأحد', subtitle: 'عمل هادئ معًا', people: '١٢ يستمعون', color: 'sky', initials: 'SR' },
];

function Avatar({ initials, color, size = 42 }: { initials: string; color: string; size?: number }) {
  const colors = useColors();
  const fill = colors[color as keyof typeof colors] as string;
  return (
    <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: fill }]}>
      <Text style={[styles.avatarText, { color: colors.ink, fontSize: size * 0.28 }]}>{initials}</Text>
    </View>
  );
}

export default function DashboardScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const topInset = insets.top + (Platform.OS === 'web' ? 67 : 0);
  const timeOfDay = useMemo(() => 'مساء الخير', []);

  return (
    <View style={[styles.container, { backgroundColor: colors.background, direction: 'rtl' }]}>
      <StatusBar style="light" />
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: topInset + 8, paddingBottom: insets.bottom + 112 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.mint }]}>ويفز / الخميس</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>{timeOfDay}، آشا</Text>
          </View>
          <View style={styles.headerActions}>
            <Pressable
              testID="notifications-button"
              style={[styles.iconButton, { backgroundColor: colors.surfaceRaised }]}
              onPress={() => undefined}
            >
              <Feather name="bell" size={18} color={colors.foreground} />
              <View style={[styles.notificationDot, { backgroundColor: colors.coral }]} />
            </Pressable>
            <Avatar initials="AS" color="gold" size={40} />
          </View>
        </View>

        <Pressable
          testID="featured-room"
          onPress={() => router.push('/room')}
          style={({ pressed }) => [
            styles.featuredCard,
            { backgroundColor: colors.mint, opacity: pressed ? 0.92 : 1 },
          ]}
        >
          <View style={styles.featuredGlow} />
          <View style={styles.livePill}>
            <View style={[styles.liveDot, { backgroundColor: colors.coral }]} />
            <Text style={[styles.liveLabel, { color: colors.ink }]}>مباشر الآن</Text>
          </View>
          <View style={styles.featuredCopy}>
            <Text style={[styles.featuredKicker, { color: colors.ink }]}>أصدقاؤك هنا</Text>
            <Text style={[styles.featuredTitle, { color: colors.ink }]}>الصالة{'\n'}الليلية</Text>
            <Text style={[styles.featuredSubtitle, { color: colors.ink }]}>٨ أصدقاء يتحدثون</Text>
          </View>
          <View style={styles.featuredArrow}>
            <Feather name="arrow-up-right" size={20} color={colors.ink} />
          </View>
          <View style={styles.featuredAvatars}>
            <Avatar initials="MN" color="coral" size={34} />
            <Avatar initials="KH" color="sky" size={34} />
            <Avatar initials="＋5" color="gold" size={34} />
          </View>
        </Pressable>

        <View style={styles.sectionHeading}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>عد إلى غرفتك</Text>
          <Pressable testID="see-all-rooms" onPress={() => router.push('/room')}>
            <Text style={[styles.link, { color: colors.mint }]}>عرض الكل</Text>
          </Pressable>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.roomRail}>
          {rooms.map((room, index) => (
            <Pressable
              testID={`room-card-${index}`}
              key={room.title}
              onPress={() => router.push('/room')}
              style={({ pressed }) => [
                styles.roomCard,
                { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <View style={styles.roomCardTop}>
                <Avatar initials={room.initials} color={room.color} size={38} />
                <Feather name="more-horizontal" size={19} color={colors.mutedForeground} />
              </View>
              <Text style={[styles.roomTitle, { color: colors.foreground }]} numberOfLines={1}>{room.title}</Text>
              <Text style={[styles.roomSubtitle, { color: colors.mutedForeground }]} numberOfLines={1}>{room.subtitle}</Text>
              <View style={styles.roomMeta}>
                <Feather name="mic" size={13} color={colors.mint} />
                <Text style={[styles.roomPeople, { color: colors.mutedForeground }]}>{room.people}</Text>
              </View>
            </Pressable>
          ))}
        </ScrollView>

        <View style={styles.sectionHeading}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>استكشف الغرف</Text>
          <Pressable testID="search-rooms" style={[styles.searchButton, { backgroundColor: colors.surfaceRaised }]} onPress={() => undefined}>
            <Feather name="search" size={17} color={colors.mutedForeground} />
          </Pressable>
        </View>

        <View style={styles.exploreList}>
          <ExploreRow icon="music" title="أصوات وأسطوانات" subtitle="لو-فاي، سول، ورفقة جميلة" count="٤٢ يستمعون" color={colors.coral} colors={colors} onPress={() => router.push('/room')} />
          <ExploreRow icon="coffee" title="نادي الصباح" subtitle="بداية هادئة معًا" count="١٨ يستمعون" color={colors.gold} colors={colors} onPress={() => router.push('/room')} />
          <ExploreRow icon="book-open" title="أفكار تستحق الحفظ" subtitle="فكرة واحدة تستحق المشاركة" count="٩ يتحدثون" color={colors.sky} colors={colors} onPress={() => router.push('/room')} />
        </View>
      </ScrollView>
    </View>
  );
}

function ExploreRow({
  icon,
  title,
  subtitle,
  count,
  color,
  colors,
  onPress,
}: {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  subtitle: string;
  count: string;
  color: string;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  return (
    <Pressable testID={`explore-${title}`} onPress={onPress} style={({ pressed }) => [styles.exploreRow, { borderBottomColor: colors.border, opacity: pressed ? 0.75 : 1 }]}>
      <View style={[styles.exploreIcon, { backgroundColor: color }]}>
        <Feather name={icon} size={18} color={colors.ink} />
      </View>
      <View style={styles.exploreCopy}>
        <Text style={[styles.exploreTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.exploreSubtitle, { color: colors.mutedForeground }]}>{subtitle}</Text>
      </View>
      <View style={styles.exploreMeta}>
        <Text style={[styles.exploreCount, { color: colors.mutedForeground }]}>{count}</Text>
        <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1.7, marginBottom: 8 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 27, letterSpacing: -0.8, textAlign: 'right' },
  headerActions: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10 },
  iconButton: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  notificationDot: { position: 'absolute', top: 8, right: 9, width: 6, height: 6, borderRadius: 3, borderWidth: 1, borderColor: '#172322' },
  avatar: { justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontFamily: 'Inter_700Bold' },
  featuredCard: { minHeight: 230, borderRadius: 26, padding: 22, overflow: 'hidden', marginBottom: 30 },
  featuredGlow: { position: 'absolute', right: -30, bottom: -48, width: 230, height: 230, borderRadius: 115, borderWidth: 32, borderColor: 'rgba(13,20,20,0.08)' },
  livePill: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20, backgroundColor: 'rgba(13,20,20,0.08)' },
  liveDot: { width: 7, height: 7, borderRadius: 4 },
  liveLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1 },
  featuredCopy: { marginTop: 28, alignItems: 'flex-end' },
  featuredKicker: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.3, opacity: 0.55 },
  featuredTitle: { fontFamily: 'Inter_700Bold', fontSize: 38, lineHeight: 39, letterSpacing: -1.5, marginTop: 8, textAlign: 'right' },
  featuredSubtitle: { fontFamily: 'Inter_500Medium', fontSize: 13, marginTop: 12, opacity: 0.72, textAlign: 'right' },
  featuredArrow: { position: 'absolute', top: 22, right: 22, width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(13,20,20,0.08)', justifyContent: 'center', alignItems: 'center' },
  featuredAvatars: { position: 'absolute', right: 20, bottom: 20, flexDirection: 'row', gap: -7 },
  sectionHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, letterSpacing: -0.4 },
  link: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  roomRail: { gap: 12, paddingBottom: 30 },
  roomCard: { width: 180, minHeight: 154, borderRadius: 18, padding: 15, borderWidth: 1 },
  roomCardTop: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  roomTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, marginBottom: 5, textAlign: 'right' },
  roomSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, marginBottom: 17, textAlign: 'right' },
  roomMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  roomPeople: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  searchButton: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  exploreList: { marginBottom: 20 },
  exploreRow: { minHeight: 72, borderBottomWidth: 1, flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  exploreIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  exploreCopy: { flex: 1 },
  exploreTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, marginBottom: 4, textAlign: 'right' },
  exploreSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, textAlign: 'right' },
  exploreMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5 },
  exploreCount: { fontFamily: 'Inter_400Regular', fontSize: 10 },
});
