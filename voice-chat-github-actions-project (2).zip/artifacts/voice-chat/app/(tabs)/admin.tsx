import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useState } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type Control = { title: string; detail: string; icon: keyof typeof Feather.glyphMap; color: 'mint' | 'coral' | 'gold' | 'sky' };

const controls: Control[] = [
  { title: 'رفع الجميع', detail: 'فتح الميكروفونات', icon: 'mic', color: 'mint' },
  { title: 'كتم الجميع', detail: 'تهدئة الغرفة', icon: 'mic-off', color: 'coral' },
  { title: 'قائمة الانتظار', detail: '٣ طلبات جديدة', icon: 'users', color: 'gold' },
  { title: 'تثبيت موضوع', detail: 'إبقاء الفكرة واضحة', icon: 'bookmark', color: 'sky' },
];

export default function AdminScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [activeControl, setActiveControl] = useState<string | null>(null);
  const topInset = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const applyControl = async (title: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setActiveControl((current) => (current === title ? null : title));
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background, direction: 'rtl' }]}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: topInset + 8, paddingBottom: insets.bottom + 112 }}>
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.coral }]}>مساحة المضيف / ٠١</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>أنت تدير المساحة.</Text>
          </View>
          <View style={[styles.headerIcon, { backgroundColor: colors.surfaceRaised }]}>
            <Feather name="sliders" size={18} color={colors.foreground} />
          </View>
        </View>

        <View style={[styles.statusCard, { backgroundColor: colors.surfaceRaised }]}>
          <View style={styles.statusTop}>
            <View style={[styles.liveBadge, { backgroundColor: colors.coral }]}>
              <View style={[styles.liveDot, { backgroundColor: colors.destructiveForeground }]} />
              <Text style={[styles.liveText, { color: colors.destructiveForeground }]}>مباشرة</Text>
            </View>
            <Text style={[styles.statusTime, { color: colors.mutedForeground }]}>٠٠:٤٨:١٢</Text>
          </View>
          <Text style={[styles.statusTitle, { color: colors.foreground }]}>الصالة الليلية</Text>
          <Text style={[styles.statusBody, { color: colors.mutedForeground }]}>١٢ شخصًا على المنصة · ٢٤ مستمعًا</Text>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>أدوات الإدارة</Text>
          <Text style={[styles.sectionHint, { color: colors.mutedForeground }]}>تحكم سريع</Text>
        </View>

        <View style={styles.controlGrid}>
          {controls.map((control) => {
            const selected = activeControl === control.title;
            const fill = colors[control.color];
            return (
              <Pressable
                key={control.title}
                testID={`admin-${control.title}`}
                onPress={() => applyControl(control.title)}
                style={({ pressed }) => [
                  styles.controlCard,
                  { backgroundColor: colors.card, borderColor: selected ? fill : colors.border, opacity: pressed ? 0.82 : 1 },
                ]}
              >
                <View style={[styles.controlIcon, { backgroundColor: fill }]}>
                  <Feather name={selected ? 'check' : control.icon} size={19} color={colors.ink} />
                </View>
                <Text style={[styles.controlTitle, { color: colors.foreground }]}>{selected ? 'تم التطبيق' : control.title}</Text>
                <Text style={[styles.controlDetail, { color: colors.mutedForeground }]}>{control.detail}</Text>
              </Pressable>
            );
          })}
        </View>

        <View style={[styles.dangerRow, { borderColor: colors.border }]}>
          <View style={[styles.dangerIcon, { backgroundColor: colors.coral }]}>
            <Feather name="log-out" size={17} color={colors.ink} />
          </View>
          <View style={styles.dangerCopy}>
            <Text style={[styles.dangerTitle, { color: colors.foreground }]}>إنهاء الغرفة</Text>
            <Text style={[styles.dangerDetail, { color: colors.mutedForeground }]}>سيتم إخراج الجميع من الغرفة</Text>
          </View>
          <Feather name="chevron-left" size={18} color={colors.mutedForeground} />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 25 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1.2, marginBottom: 8, textAlign: 'right' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 29, letterSpacing: -1, textAlign: 'right' },
  headerIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  statusCard: { marginHorizontal: 20, borderRadius: 22, padding: 19, minHeight: 142, marginBottom: 29 },
  statusTop: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  liveBadge: { borderRadius: 14, paddingHorizontal: 9, paddingVertical: 6, flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  liveText: { fontFamily: 'Inter_700Bold', fontSize: 9 },
  statusTime: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  statusTitle: { fontFamily: 'Inter_700Bold', fontSize: 22, textAlign: 'right' },
  statusBody: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 6, textAlign: 'right' },
  sectionHeader: { paddingHorizontal: 20, flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20 },
  sectionHint: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  controlGrid: { paddingHorizontal: 20, flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 11 },
  controlCard: { width: '48.3%', minHeight: 136, borderRadius: 18, borderWidth: 1, padding: 14, alignItems: 'flex-end' },
  controlIcon: { alignSelf: 'flex-start', width: 42, height: 42, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginBottom: 14 },
  controlTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, textAlign: 'right' },
  controlDetail: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 5, textAlign: 'right' },
  dangerRow: { marginHorizontal: 20, marginTop: 26, padding: 13, borderWidth: 1, borderRadius: 16, flexDirection: 'row-reverse', alignItems: 'center', gap: 11 },
  dangerIcon: { width: 34, height: 34, borderRadius: 11, justifyContent: 'center', alignItems: 'center' },
  dangerCopy: { flex: 1 },
  dangerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 13, textAlign: 'right' },
  dangerDetail: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 4, textAlign: 'right' },
});