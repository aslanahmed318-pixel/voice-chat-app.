import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useState } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type Gift = { name: string; detail: string; price: string; icon: keyof typeof Feather.glyphMap; color: 'mint' | 'coral' | 'gold' | 'sky' };

const gifts: Gift[] = [
  { name: 'تصفيق', detail: 'لفتة لطيفة', price: '١٠', icon: 'thumbs-up', color: 'mint' },
  { name: 'شرارة', detail: 'للفكرة الجميلة', price: '٢٥', icon: 'zap', color: 'coral' },
  { name: 'قهوة', detail: 'خذ استراحة', price: '٥٠', icon: 'coffee', color: 'gold' },
  { name: 'نجمة', detail: 'للحظة مميزة', price: '١٠٠', icon: 'star', color: 'sky' },
];

export default function GiftsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [sentGift, setSentGift] = useState<string | null>(null);
  const topInset = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const sendGift = async (giftName: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSentGift(giftName);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background, direction: 'rtl' }]}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: topInset + 8, paddingBottom: insets.bottom + 112 }}>
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.gold }]}>لحظات جميلة / ٠١</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>أرسل طاقة جميلة.</Text>
          </View>
          <View style={[styles.headerIcon, { backgroundColor: colors.surfaceRaised }]}>
            <Feather name="gift" size={19} color={colors.foreground} />
          </View>
        </View>

        <View style={[styles.balanceCard, { backgroundColor: colors.mint }]}>
          <View style={[styles.balanceIcon, { backgroundColor: 'rgba(13,20,20,0.10)' }]}>
            <Feather name="heart" size={22} color={colors.ink} />
          </View>
          <Text style={[styles.balanceKicker, { color: colors.ink }]}>رصيدك</Text>
          <View style={styles.balanceRow}>
            <Text style={[styles.balance, { color: colors.ink }]}>٢٤٠</Text>
            <Text style={[styles.balanceUnit, { color: colors.ink }]}>نقطة</Text>
          </View>
          <Text style={[styles.balanceNote, { color: colors.ink }]}>أرسل هدية لمن يتحدث الآن</Text>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>اختر هدية</Text>
          <Text style={[styles.sectionHint, { color: colors.mutedForeground }]}>في الصالة الليلية</Text>
        </View>

        <View style={styles.giftGrid}>
          {gifts.map((gift) => {
            const selected = sentGift === gift.name;
            const fill = colors[gift.color];
            return (
              <Pressable
                key={gift.name}
                testID={`gift-${gift.name}`}
                onPress={() => sendGift(gift.name)}
                style={({ pressed }) => [
                  styles.giftCard,
                  { backgroundColor: colors.card, borderColor: selected ? fill : colors.border, opacity: pressed ? 0.82 : 1 },
                ]}
              >
                <View style={[styles.giftIcon, { backgroundColor: fill }]}>
                  <Feather name={gift.icon} size={20} color={colors.ink} />
                </View>
                <Text style={[styles.giftName, { color: colors.foreground }]}>{selected ? 'تم الإرسال' : gift.name}</Text>
                <Text style={[styles.giftDetail, { color: colors.mutedForeground }]}>{gift.detail}</Text>
                <View style={styles.giftPrice}>
                  <Feather name="circle" size={10} color={colors.gold} />
                  <Text style={[styles.giftPriceText, { color: colors.mutedForeground }]}>{gift.price}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>

        <View style={[styles.note, { borderColor: colors.border }]}>
          <Feather name="info" size={16} color={colors.mint} />
          <Text style={[styles.noteText, { color: colors.mutedForeground }]}>الهدايا تقدير بسيط. أرسلها لمن جعل الغرفة أجمل اليوم.</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 25 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1.2, marginBottom: 8, textAlign: 'right' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 29, letterSpacing: -1, textAlign: 'right' },
  headerIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  balanceCard: { marginHorizontal: 20, borderRadius: 24, padding: 20, minHeight: 172, overflow: 'hidden', marginBottom: 30 },
  balanceIcon: { width: 44, height: 44, borderRadius: 15, justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  balanceKicker: { fontFamily: 'Inter_700Bold', fontSize: 10, opacity: 0.65, textAlign: 'right' },
  balanceRow: { flexDirection: 'row-reverse', alignItems: 'baseline', gap: 7, marginTop: 1 },
  balance: { fontFamily: 'Inter_700Bold', fontSize: 40, letterSpacing: -1.5 },
  balanceUnit: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  balanceNote: { fontFamily: 'Inter_500Medium', fontSize: 12, opacity: 0.72, marginTop: 5, textAlign: 'right' },
  sectionHeader: { paddingHorizontal: 20, flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, textAlign: 'right' },
  sectionHint: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  giftGrid: { paddingHorizontal: 20, flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 11 },
  giftCard: { width: '48.3%', minHeight: 156, borderRadius: 18, borderWidth: 1, padding: 14, alignItems: 'flex-end' },
  giftIcon: { alignSelf: 'flex-start', width: 42, height: 42, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginBottom: 14 },
  giftName: { fontFamily: 'Inter_600SemiBold', fontSize: 14, textAlign: 'right' },
  giftDetail: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 4, textAlign: 'right' },
  giftPrice: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, marginTop: 12 },
  giftPriceText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  note: { marginHorizontal: 20, marginTop: 25, borderRadius: 16, borderWidth: 1, padding: 14, flexDirection: 'row-reverse', gap: 9, alignItems: 'flex-start' },
  noteText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, textAlign: 'right' },
});